package folderlocker;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import java.io.File;
import java.nio.file.Files;

public class Main extends Application {

    private File selectedFolder;
    private File passwordFile;
    private Label statusLabel;
    private ImageView statusIcon;

    @Override
    public void start(Stage stage) {

        // Heading
        Label heading = new Label("🔒 Folder Locker");
        heading.setFont(Font.font("Arial", 28));
        heading.setTextFill(Color.DARKBLUE);

        // Buttons
        Button selectBtn = new Button("Select Folder");
        Button lockBtn = new Button("Lock Folder");
        Button unlockBtn = new Button("Unlock Folder");

        lockBtn.setDisable(true);
        unlockBtn.setDisable(true);

        // Tooltips
        selectBtn.setTooltip(new Tooltip("Select the folder you want to lock/unlock"));
        lockBtn.setTooltip(new Tooltip("Lock the selected folder with a password"));
        unlockBtn.setTooltip(new Tooltip("Unlock the selected folder with your password"));

        // Status Label + Icon
        statusLabel = new Label("Status: No folder selected");
        statusLabel.setFont(Font.font("Arial", 16));
        statusLabel.setTextFill(Color.DARKRED);

        statusIcon = new ImageView();
        statusIcon.setFitHeight(24);
        statusIcon.setFitWidth(24);

        HBox statusBox = new HBox(10, statusIcon, statusLabel);
        statusBox.setAlignment(Pos.CENTER);

        // Button actions
        selectBtn.setOnAction(e -> {
            DirectoryChooser chooser = new DirectoryChooser();
            chooser.setTitle("Select Folder");
            selectedFolder = chooser.showDialog(stage);

            if (selectedFolder != null) {
                passwordFile = new File(selectedFolder.getAbsolutePath() + ".pass");
                lockBtn.setDisable(false);
                unlockBtn.setDisable(false);
                statusLabel.setText("Status: Folder selected, not locked");
                statusLabel.setTextFill(Color.ORANGE);
                // Optional: add folder icon in src/folderlocker
                // statusIcon.setImage(new Image(getClass().getResourceAsStream("folder.png")));
            }
        });

        lockBtn.setOnAction(e -> lockFolder());
        unlockBtn.setOnAction(e -> unlockFolder());

        // Styling buttons
        for (Button btn : new Button[]{selectBtn, lockBtn, unlockBtn}) {
            btn.setMaxWidth(Double.MAX_VALUE);
            btn.setStyle("""
                    -fx-background-color: #2c3e50; 
                    -fx-text-fill: white; 
                    -fx-font-size: 14px; 
                    -fx-padding: 10 20 10 20; 
                    -fx-background-radius: 10;
                    """);
            btn.setOnMouseEntered(ev -> btn.setStyle("""
                    -fx-background-color: #34495e; 
                    -fx-text-fill: white; 
                    -fx-font-size: 14px; 
                    -fx-padding: 10 20 10 20; 
                    -fx-background-radius: 10;
                    """));
            btn.setOnMouseExited(ev -> btn.setStyle("""
                    -fx-background-color: #2c3e50; 
                    -fx-text-fill: white; 
                    -fx-font-size: 14px; 
                    -fx-padding: 10 20 10 20; 
                    -fx-background-radius: 10;
                    """));
        }

        // Layout
        VBox root = new VBox(20, heading, selectBtn, lockBtn, unlockBtn, statusBox);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(25));
        root.setStyle("-fx-background-color: #ecf0f1;"); // light gray background

        stage.setScene(new Scene(root, 450, 400));
        stage.setTitle("Folder Locker");
        stage.show();
    }

    private void lockFolder() {
        PasswordField passwordField = new PasswordField();
        TextField showPass = new TextField();
        showPass.setManaged(false);
        showPass.setVisible(false);

        Button toggle = new Button("Show");
        toggle.setStyle("-fx-font-size: 12px; -fx-padding: 2 5 2 5;");

        toggle.setOnAction(e -> {
            if (showPass.isVisible()) {
                showPass.setVisible(false);
                showPass.setManaged(false);
                passwordField.setText(showPass.getText());
                passwordField.setVisible(true);
                passwordField.setManaged(true);
                toggle.setText("Show");
            } else {
                showPass.setText(passwordField.getText());
                showPass.setVisible(true);
                showPass.setManaged(true);
                passwordField.setVisible(false);
                passwordField.setManaged(false);
                toggle.setText("Hide");
            }
        });

        HBox inputBox = new HBox(10, passwordField, showPass, toggle);
        inputBox.setAlignment(Pos.CENTER);

        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Lock Folder");
        dialog.setHeaderText("Set Password to Lock Folder");
        dialog.getDialogPane().setContent(inputBox);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> btn == ButtonType.OK ? passwordField.getText() : null);
        dialog.showAndWait().ifPresent(password -> {
            try {
                Files.writeString(passwordFile.toPath(), password);

                // Keep the original locking logic
                String command = "icacls \"" + selectedFolder.getAbsolutePath()
                        + "\" /deny Everyone:(OI)(CI)F";
                Runtime.getRuntime().exec(command).waitFor();

                statusLabel.setText("Status: Locked ✅");
                statusLabel.setTextFill(Color.GREEN);
                showInfo("Folder locked successfully ✅");

            } catch (Exception ex) {
                showError("Locking failed. Run NetBeans as Administrator.");
            }
        });
    }

    private void unlockFolder() {
        if (!passwordFile.exists()) {
            showError("Folder is not locked");
            return;
        }

        PasswordField passwordField = new PasswordField();
        TextField showPass = new TextField();
        showPass.setManaged(false);
        showPass.setVisible(false);

        Button toggle = new Button("Show");
        toggle.setStyle("-fx-font-size: 12px; -fx-padding: 2 5 2 5;");

        toggle.setOnAction(e -> {
            if (showPass.isVisible()) {
                showPass.setVisible(false);
                showPass.setManaged(false);
                passwordField.setText(showPass.getText());
                passwordField.setVisible(true);
                passwordField.setManaged(true);
                toggle.setText("Show");
            } else {
                showPass.setText(passwordField.getText());
                showPass.setVisible(true);
                showPass.setManaged(true);
                passwordField.setVisible(false);
                passwordField.setManaged(false);
                toggle.setText("Hide");
            }
        });

        HBox inputBox = new HBox(10, passwordField, showPass, toggle);
        inputBox.setAlignment(Pos.CENTER);

        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Unlock Folder");
        dialog.setHeaderText("Enter Password to Unlock");
        dialog.getDialogPane().setContent(inputBox);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> btn == ButtonType.OK ? passwordField.getText() : null);
        dialog.showAndWait().ifPresent(input -> {
            try {
                String saved = Files.readString(passwordFile.toPath());

                if (!saved.equals(input)) {
                    showError("Wrong password ❌");
                    return;
                }

                String command = "icacls \"" + selectedFolder.getAbsolutePath()
                        + "\" /remove:d Everyone";
                Runtime.getRuntime().exec(command).waitFor();

                passwordFile.delete();
                statusLabel.setText("Status: Unlocked ✅");
                statusLabel.setTextFill(Color.BLUE);
                showInfo("Folder unlocked successfully ✅");

            } catch (Exception ex) {
                showError("Unlock failed");
            }
        });
    }

    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
        alert.setHeaderText(null);
        alert.show();
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg);
        alert.setHeaderText(null);
        alert.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
